from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="It's a Credit Risk Package",
    author="Ankit Marwaha",
    packages=find_packages(),
    license="MIT"
)
